/**
 * Created by c.moore-hill on 06/05/2015.
 */

/**
 * Created by c.moore-hill on 06/05/2015.
 */

var PatientSearch = function(){

}


var PatientDetail = function(){

}