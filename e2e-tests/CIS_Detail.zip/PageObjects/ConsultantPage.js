/**
 * Created by c.moore-hill on 06/05/2015.
 */

var ConsultSearch = function(){

}


var ConsultDetail = function(){

}

